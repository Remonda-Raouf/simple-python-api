
Python Weather API Assessment

Instructions:

1. Install dependencies:
   pip install fastapi uvicorn requests

2. Run the server:
   python server.py

3. In a separate terminal, run the client:
   python client.py

Expected Output:
   Toronto: 22°C
   Montreal: 20°C
   Vancouver: 18°C

If the API key is wrong or missing:
   Failed to fetch weather data: Unauthorized
