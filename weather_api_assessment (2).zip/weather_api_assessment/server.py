from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
import uvicorn

app = FastAPI()

API_KEY = "mysecretkey"

weather_data = [
    {"city": "Toronto", "temperature": 22, "condition": "Sunny"},
    {"city": "Montreal", "temperature": 20, "condition": "Cloudy"},
    {"city": "Vancouver", "temperature": 18, "condition": "Rainy"}
]

@app.middleware("http")
async def check_api_key(request: Request, call_next):
    if request.url.path == "/weather":
        key = request.headers.get("X-API-KEY")
        if key != API_KEY:
            return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
    return await call_next(request)

@app.get("/weather")
async def get_weather():
    return weather_data

if __name__ == "__main__":
    uvicorn.run("server:app", port=8000, reload=True)
