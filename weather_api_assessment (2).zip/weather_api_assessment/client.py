import requests

URL = "http://localhost:8000/weather"
HEADERS = {"X-API-KEY": "mysecretkey"}

response = requests.get(URL, headers=HEADERS)

if response.status_code == 200:
    data = response.json()
    for city in data:
        print(f"{city['city']}: {city['temperature']}°C")
elif response.status_code == 401:
    print("Failed to fetch weather data: Unauthorized")
else:
    print(f"Error: {response.status_code}")
